# Bộ kiểm thử MiniRTS (không cần SDL3)

Kiểm thử phần **mô phỏng** (đường đi, đội hình, va chạm, hàng đợi tìm đường, AI): không mở cửa sổ, không cần GPU,
không cần cài SDL3. SDL được thay bằng `fake_sdl/SDL3/SDL.h` (các hàm vẽ/chuột là hàm rỗng).

## Cài đặt
Giải nén vào **thư mục gốc dự án** (cạnh `CMakeLists.txt`, `Maps/`, `Data/`) để có `Mini-RTS/tests/...`.
Nếu đã giải nén `Mini-RTS.zip` có sẵn `tests/PathingTests.cpp` thì cứ ghi đè.

## Cách chạy

**Linux / macOS / WSL / MSYS2 (g++ hoặc clang++):**
```bash
bash tests/run_tests.sh                      # PathingTests + StressTest, kèm AddressSanitizer + UBSan
bash tests/run_tests.sh --bench              # thêm số liệu hiệu năng A* vs FlowField
NO_SAN=1 bash tests/run_tests.sh             # tắt sanitizer
STRESS=1000 SEED=42 bash tests/run_tests.sh  # chỉnh số ván / seed của StressTest
```

**Windows / MSVC (CMake độc lập, không đụng tới CMakeLists.txt của game):**
```
cmake -S tests/standalone -B build-tests
cmake --build build-tests --config Debug
ctest --test-dir build-tests -C Debug --output-on-failure
```
> `tests/standalone/CMakeLists.txt` chưa được chạy thử (nơi soạn không có cmake); `run_tests.sh` thì đã chạy.
> Nếu Git đổi xuống dòng của `run_tests.sh` thành CRLF, hãy dùng `bash tests/run_tests.sh` hoặc đường CMake.

**Với SDL3 thật** (bản build của game): `cmake -S . -B build -DMINIRTS_BUILD_TESTS=ON`, build target `PathingTests`.

Kết quả mong đợi: `147 kiểm tra, 0 thất bại.` và `ĐẠT` ở cuối StressTest. Mã thoát khác 0 nếu có kiểm tra thất bại.

## Nội dung
| File | Làm gì |
|---|---|
| `PathingTests.cpp` | 147 kiểm tra: `Path`; A\* so với đáp án chuẩn (Dijkstra viết riêng) trên bản đồ ngẫu nhiên; làm mượt đường; đường tới điểm gần đích nhất; gán slot (đối chiếu vét cạn, không đường cắt nhau); `FlowField`; mô phỏng qua tường, hai đoàn ngược chiều, nút cổ chai, bị tường chặn, đổi lệnh, hàng đợi có ngân sách, AI về nhà, đuổi mục tiêu không với tới, `Map02.txt`, 6 lính đánh 3 địch, tính xác định, 150 ván ngẫu nhiên |
| `StressTest.cpp` | Nhiều ván ngẫu nhiên hơn (mặc định 300, chỉnh được): không ai đè lên tường, không toạ độ hỏng, mọi lệnh đi kết thúc, hàng đợi cạn |
| `fake_sdl/SDL3/SDL.h` | SDL giả chỉ đủ để biên dịch phần mô phỏng |
| `run_tests.sh`, `standalone/CMakeLists.txt` | Hai cách build và chạy |

## Khi code thêm hàm SDL mới
Nếu biên dịch bộ test báo thiếu một hàm `SDL_...`, thêm một hàm rỗng cùng chữ ký vào `fake_sdl/SDL3/SDL.h`.
Khi thêm file `.cpp` mới vào game, thêm vào danh sách `CORE` trong `run_tests.sh` và `CORE_SOURCES` trong `standalone/CMakeLists.txt`
(cùng danh sách `MINIRTS_CORE_SOURCES` ở `CMakeLists.txt` gốc).

## Giới hạn
Bộ test không kiểm tra phần vẽ, âm thanh, nhận sự kiện chuột/phím hay vòng đời cửa sổ (`main.cpp`, `ui/Menu.cpp`, hình vẽ trong `Render.cpp`).
Chạy thử game thật vẫn là cách duy nhất để thấy hình vẽ và cảm giác điều khiển.
