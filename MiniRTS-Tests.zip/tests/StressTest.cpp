// Stress mô phỏng: chạy nhiều ván NGẪU NHIÊN (bản đồ có tường, khe hẹp, vật cản; 1–3 nhóm tới 24 lính; lệnh đi tới điểm bất kỳ)
// rồi kiểm các bất biến. Nặng hơn TestRandomStress trong PathingTests.cpp: số ván và seed chỉnh được.
//
//   StressTest [số_ván=300] [seed=987654321]
//
// Thoát mã khác 0 nếu có vi phạm bất biến:
//   - có lính đè lên tường (hitbox 40px chồng lên ô nước/đá)
//   - toạ độ không hợp lệ (NaN / vô cực)
//   - lệnh đi không kết thúc sau 90 giây mô phỏng (chạy mãi / xoay vòng)
//   - hàng đợi tìm đường còn yêu cầu khi mọi lính đã dừng
// Các con số "lệch khỏi vị trí đội hình" chỉ để tham khảo, không làm test thất bại (xem ROADMAP, mục nợ kỹ thuật số 3).
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <utility>
#include <vector>

#include "Pathfinder.h"
#include "TileMap.h"
#include "game/GameState.h"
#include "game/Orders.h"
#include "game/PathService.h"
#include "game/Simulation.h"

namespace {
    struct Rng {
        std::uint32_t s;
        std::uint32_t Next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
        int Int(int lo, int hi) { return lo + static_cast<int>(Next() % static_cast<std::uint32_t>(hi - lo + 1)); }
    };

    Waypoint Center(int row, int col) { return { (static_cast<float>(col) + 0.5f) * 64.0f, (static_cast<float>(row) + 0.5f) * 64.0f }; }
    bool Moving(const Unit& u) { return u.hasMoveGoal || !u.path.empty() || u.pathPending; }
}

int main(int argc, char** argv) {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    const int scenarios = argc > 1 ? std::atoi(argv[1]) : 300;
    Rng rng{ static_cast<std::uint32_t>(argc > 2 ? std::strtoul(argv[2], nullptr, 10) : 987654321u) };
    if (rng.s == 0) rng.s = 1;

    long wallViolations = 0, nanCount = 0;
    int timeouts = 0, queueLeft = 0, totalUnits = 0, unreachableSlot = 0, displaced = 0;
    float worst = 0.0f;

    for (int sc = 0; sc < scenarios; ++sc) {
        // --- Dựng bản đồ ngẫu nhiên ---
        const int rows = rng.Int(14, 40), cols = rng.Int(18, 50);
        std::vector<std::string> R(static_cast<size_t>(rows), std::string(static_cast<size_t>(cols), '.'));
        const int density = rng.Int(5, 30);
        for (auto& line : R) for (auto& ch : line) if (rng.Int(0, 99) < density) ch = rng.Int(0, 1) ? '#' : '~';
        const int walls = rng.Int(0, 3);
        for (int w = 0; w < walls; ++w) { // tường dọc dài, có đúng một khe
            const int c = rng.Int(4, cols - 5), gap = rng.Int(1, rows - 2);
            for (int r = 0; r < rows; ++r) if (r != gap) R[static_cast<size_t>(r)][static_cast<size_t>(c)] = '#';
        }
        GameState g;
        g.unitTypes.LoadBuiltInDefaults();
        g.map.rows = rows; g.map.cols = cols; g.map.tileSize = 64.0f;
        for (const auto& line : R) for (char ch : line) g.map.data.push_back(ch == '#' ? Tile::Rock : ch == '~' ? Tile::Water : Tile::Grass);

        auto pickFree = [&](int rLo, int rHi, int cLo, int cHi, Waypoint& out) {
            for (int t = 0; t < 400; ++t) {
                out = Center(rng.Int(rLo, rHi), rng.Int(cLo, cHi));
                if (!g.map.CanBoxStandAt(out.x, out.y, kSquareSize)) continue;
                bool ok = true;
                for (const auto& u : g.units) if (std::hypot(u.x - out.x, u.y - out.y) < kSquareSize) ok = false;
                if (ok) return true;
            }
            return false;
        };

        // --- 1–3 nhóm, mỗi nhóm nhận một lệnh đi tới điểm bất kỳ ---
        const int nGroups = rng.Int(1, 3);
        std::vector<std::vector<EntityId>> groups(static_cast<size_t>(nGroups));
        for (int gi = 0; gi < nGroups; ++gi) {
            const int n = rng.Int(1, 24), c0 = rng.Int(0, cols - 6), r0 = rng.Int(0, rows - 6);
            for (int i = 0; i < n; ++i) {
                Waypoint p;
                if (pickFree(r0, std::min(rows - 1, r0 + 5), c0, std::min(cols - 1, c0 + 5), p)) {
                    groups[static_cast<size_t>(gi)].push_back(g.AddUnit(p.x, p.y, Team::Player, g.unitTypes.DefaultIndexFor(Team::Player)).id);
                }
            }
        }
        std::vector<std::pair<EntityId, Waypoint>> ownGoal; // đích riêng (vị trí đội hình) của từng lính
        for (int gi = 0; gi < nGroups; ++gi) {
            for (auto& u : g.units) u.selected = false;
            for (EntityId id : groups[static_cast<size_t>(gi)]) g.FindUnit(id)->selected = true;
            const Waypoint goal = Center(rng.Int(0, rows - 1), rng.Int(0, cols - 1));
            IssueFormationMoveOrder(g, goal.x, goal.y);
            for (EntityId id : groups[static_cast<size_t>(gi)]) ownGoal.push_back({ id, g.FindUnit(id)->moveGoal });
        }
        totalUnits += static_cast<int>(g.units.size());

        // --- Chạy tới khi mọi lệnh đi kết thúc (tối đa 90 giây mô phỏng), kiểm bất biến mỗi tick ---
        const int maxTicks = 90 * kTickRate;
        int t = 0;
        for (; t < maxTicks; ++t) {
            bool any = !g.pathQueue.empty();
            for (const auto& u : g.units) if (Moving(u)) { any = true; break; }
            if (!any) break;
            StepSimulation(g, kTickDt);
            for (const auto& u : g.units) {
                if (!std::isfinite(u.x) || !std::isfinite(u.y)) ++nanCount;
                if (!g.map.CanBoxStandAt(u.x, u.y, kSquareSize)) ++wallViolations;
            }
        }
        const float seconds = static_cast<float>(t) * kTickDt;
        worst = std::max(worst, seconds);
        if (t >= maxTicks) {
            ++timeouts;
            std::printf("  ván %d HẾT GIỜ (bản đồ %dx%d, %zu lính)\n", sc, cols, rows, g.units.size());
        }
        if (!g.pathQueue.empty()) ++queueLeft;

        // --- Tham khảo: lính dừng xa vị trí đội hình dù vị trí đó với tới được ---
        for (const auto& og : ownGoal) {
            const Unit* u = g.FindUnit(og.first);
            if (!u || Moving(*u)) continue;
            const PathResult res = Pathfinder::Find(g.map, u->x, u->y, og.second.x, og.second.y);
            if (res.partial) { ++unreachableSlot; continue; }
            float remain = 0.0f;
            Waypoint prev{ u->x, u->y };
            for (const auto& w : res.points) { remain += std::hypot(w.x - prev.x, w.y - prev.y); prev = w; }
            if (remain > 2.0f * 64.0f) ++displaced;
        }
    }

    std::printf("ván=%d  lính=%d  lâu nhất=%.1fs\n", scenarios, totalUnits, static_cast<double>(worst));
    std::printf("  BẤT BIẾN  đè tường=%ld  toạ độ hỏng=%ld  chạy mãi=%d  hàng đợi còn=%d\n", wallViolations, nanCount, timeouts, queueLeft);
    std::printf("  THAM KHẢO vị trí đội hình không với tới=%d  dừng cách vị trí đội hình >2 ô (thường do bị đẩy)=%d\n", unreachableSlot, displaced);
    const bool ok = wallViolations == 0 && nanCount == 0 && timeouts == 0 && queueLeft == 0;
    std::printf("%s\n", ok ? "ĐẠT" : "THẤT BẠI");
    return ok ? 0 : 1;
}
