// ===========================================================================
// SDL3 GIẢ — CHỈ DÙNG ĐỂ BIÊN DỊCH VÀ CHẠY BỘ KIỂM THỬ KHI KHÔNG CÓ SDL3 THẬT.
// KHÔNG phải một phần của game và không được đưa vào đường include của bản build thật.
//
// Phần mô phỏng (đơn vị, đường đi, va chạm, AI...) chỉ gọi SDL ở vài chỗ: ghi log, vẽ, đọc chuột/phím.
// Ở đây các hàm vẽ/chuột là hàm rỗng, SDL_Log in ra stdout (tắt bằng -DFAKE_SDL_QUIET).
// Nếu sau này code dùng thêm một hàm SDL mới và biên dịch báo thiếu, chỉ cần thêm hàm rỗng tương ứng vào đây.
// ===========================================================================
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdarg>
#include <cstdint>
#include <cstdio>

typedef std::uint8_t Uint8;
typedef std::uint32_t Uint32;
typedef std::uint64_t Uint64;

struct SDL_Renderer {};
struct SDL_FRect { float x, y, w, h; };
struct SDL_FPoint { float x, y; };

enum SDL_Scancode {
    SDL_SCANCODE_UP = 82, SDL_SCANCODE_DOWN = 81, SDL_SCANCODE_LEFT = 80, SDL_SCANCODE_RIGHT = 79, SDL_SCANCODE_SPACE = 44
};

#ifndef FAKE_SDL_QUIET
inline void SDL_Log(const char* fmt, ...) { std::va_list a; va_start(a, fmt); std::vprintf(fmt, a); std::printf("\n"); va_end(a); }
#else
inline void SDL_Log(const char*, ...) {}
#endif

// Vẽ: không làm gì.
inline bool SDL_SetRenderDrawColor(SDL_Renderer*, Uint8, Uint8, Uint8, Uint8) { return true; }
inline bool SDL_RenderFillRect(SDL_Renderer*, const SDL_FRect*) { return true; }
inline bool SDL_RenderRect(SDL_Renderer*, const SDL_FRect*) { return true; }
inline bool SDL_RenderLine(SDL_Renderer*, float, float, float, float) { return true; }
inline bool SDL_RenderDebugText(SDL_Renderer*, float, float, const char*) { return true; }
inline bool SDL_RenderClear(SDL_Renderer*) { return true; }
inline bool SDL_RenderPresent(SDL_Renderer*) { return true; }

// Đầu vào / hệ thống.
inline bool SDL_GetMouseState(float* x, float* y) { if (x) *x = 0; if (y) *y = 0; return false; }
inline const char* SDL_GetBasePath() { return "./"; }

// Hình học (cài đặt thật vì Selection.cpp dùng để chọn quân).
inline bool SDL_HasRectIntersectionFloat(const SDL_FRect* a, const SDL_FRect* b) {
    return !(a->x + a->w < b->x || b->x + b->w < a->x || a->y + a->h < b->y || b->y + b->h < a->y);
}
inline bool SDL_PointInRectFloat(const SDL_FPoint* p, const SDL_FRect* r) {
    return p->x >= r->x && p->x < r->x + r->w && p->y >= r->y && p->y < r->y + r->h;
}
