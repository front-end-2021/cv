#!/usr/bin/env bash
# Biên dịch và chạy bộ kiểm thử bằng SDL GIẢ (không cần cài SDL3). Cần g++ hoặc clang++ (C++17).
#   tests/run_tests.sh                # PathingTests + StressTest, có AddressSanitizer/UBSan
#   tests/run_tests.sh --bench        # thêm số liệu hiệu năng A* so với FlowField
#   NO_SAN=1 tests/run_tests.sh       # tắt sanitizer (nhanh hơn, hoặc khi trình biên dịch không hỗ trợ)
#   STRESS=1000 SEED=42 tests/run_tests.sh   # chỉnh số ván / seed của StressTest
#   CXX=clang++ tests/run_tests.sh
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${ROOT}/build-tests"
CXX="${CXX:-g++}"
mkdir -p "${OUT}"

# Mã nguồn dùng chung với game (mọi thứ trừ main.cpp và ui/Menu.cpp). Giữ khớp với MINIRTS_CORE_SOURCES trong CMakeLists.txt.
CORE=(
  TileMap.cpp Pathfinder.cpp FlowField.cpp Utils.cpp camera/camera.cpp
  entity/Entity.cpp entity/UnitType.cpp entity/Unit.cpp
  game/GameState.cpp game/PathService.cpp game/Movement.cpp game/World.cpp game/Formation.cpp
  game/Orders.cpp game/Ai.cpp game/Simulation.cpp game/Selection.cpp game/Game.cpp game/Render.cpp
)

FLAGS=(-std=c++17 -O1 -g -Wall -Wextra -DFAKE_SDL_QUIET -I"${ROOT}/tests/fake_sdl" -I"${ROOT}")
if [[ "${NO_SAN:-0}" != "1" ]]; then
  FLAGS+=(-fsanitize=address,undefined -fno-sanitize-recover=undefined)
fi

cd "${ROOT}"
SRCS=(); for f in "${CORE[@]}"; do SRCS+=("${ROOT}/${f}"); done

echo "== Biên dịch (${CXX}${NO_SAN:+, không sanitizer})"
"${CXX}" "${FLAGS[@]}" "${SRCS[@]}" tests/PathingTests.cpp -o "${OUT}/PathingTests"
"${CXX}" "${FLAGS[@]}" "${SRCS[@]}" tests/StressTest.cpp   -o "${OUT}/StressTest"

# Chạy từ thư mục gốc dự án để test tìm thấy Maps/ và Data/.
echo "== PathingTests"
"${OUT}/PathingTests" "$@"
echo "== StressTest (${STRESS:-300} ván, seed ${SEED:-987654321})"
"${OUT}/StressTest" "${STRESS:-300}" "${SEED:-987654321}"
