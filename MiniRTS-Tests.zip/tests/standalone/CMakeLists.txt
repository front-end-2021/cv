# Dự án CMake ĐỘC LẬP để build và chạy bộ kiểm thử bằng SDL GIẢ (không tải/cài SDL3). Dùng được cả với MSVC.
#   cmake -S tests/standalone -B build-tests
#   cmake --build build-tests --config Debug
#   ctest --test-dir build-tests -C Debug --output-on-failure
# (Chưa chạy thử trong môi trường soạn thảo vì không có cmake; script tests/run_tests.sh thì đã chạy.)
cmake_minimum_required(VERSION 3.16)
project(MiniRTSTests LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

get_filename_component(MINIRTS_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/../.." ABSOLUTE)

# Giữ khớp với MINIRTS_CORE_SOURCES trong CMakeLists.txt của game (ở đây chỉ cần file .cpp).
set(CORE_SOURCES
    ${MINIRTS_ROOT}/TileMap.cpp
    ${MINIRTS_ROOT}/Pathfinder.cpp
    ${MINIRTS_ROOT}/FlowField.cpp
    ${MINIRTS_ROOT}/Utils.cpp
    ${MINIRTS_ROOT}/camera/camera.cpp
    ${MINIRTS_ROOT}/entity/Entity.cpp
    ${MINIRTS_ROOT}/entity/UnitType.cpp
    ${MINIRTS_ROOT}/entity/Unit.cpp
    ${MINIRTS_ROOT}/game/GameState.cpp
    ${MINIRTS_ROOT}/game/PathService.cpp
    ${MINIRTS_ROOT}/game/Movement.cpp
    ${MINIRTS_ROOT}/game/World.cpp
    ${MINIRTS_ROOT}/game/Formation.cpp
    ${MINIRTS_ROOT}/game/Orders.cpp
    ${MINIRTS_ROOT}/game/Ai.cpp
    ${MINIRTS_ROOT}/game/Simulation.cpp
    ${MINIRTS_ROOT}/game/Selection.cpp
    ${MINIRTS_ROOT}/game/Game.cpp
    ${MINIRTS_ROOT}/game/Render.cpp)

option(MINIRTS_SANITIZE "Bat AddressSanitizer/UBSan (GCC/Clang)" ON)

foreach(target PathingTests StressTest)
    add_executable(${target} ${MINIRTS_ROOT}/tests/${target}.cpp ${CORE_SOURCES})
    # fake_sdl phải đứng trước để #include <SDL3/SDL.h> lấy bản giả.
    target_include_directories(${target} PRIVATE ${MINIRTS_ROOT}/tests/fake_sdl ${MINIRTS_ROOT})
    target_compile_definitions(${target} PRIVATE FAKE_SDL_QUIET)
    if(MSVC)
        target_compile_options(${target} PRIVATE /utf-8 /W4)
    else()
        target_compile_options(${target} PRIVATE -Wall -Wextra)
        if(MINIRTS_SANITIZE)
            target_compile_options(${target} PRIVATE -g -fsanitize=address,undefined -fno-sanitize-recover=undefined)
            target_link_options(${target} PRIVATE -fsanitize=address,undefined)
        endif()
    endif()
endforeach()

enable_testing()
# Chạy từ thư mục gốc dự án để tìm thấy Maps/ và Data/.
add_test(NAME PathingTests COMMAND PathingTests WORKING_DIRECTORY ${MINIRTS_ROOT})
add_test(NAME StressTest   COMMAND StressTest 300 WORKING_DIRECTORY ${MINIRTS_ROOT})
